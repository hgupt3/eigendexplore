## Sharpa asset preparation

- Source: `https://github.com/sharpa-robotics/sharpa-urdf-usd-xml.git` at
  `6eea427eb24189519f32b9f21674cd534d3f973c`, using the left and right
  `wave_01` URDFs.
- Rebuild with `dexmachina/hand_proc/port_sharpa_wuji.py`, passing pinned
  Sharpa and Wuji source checkouts and `dexmachina/assets` as the asset root.
- The script removes the MuJoCo compiler tag, copies every referenced mesh
  into side-specific directories, and prepends DexMachina's standard
  tx/ty/tz/roll/pitch/yaw forearm chain.
- The yaw joint connects directly to `left_hand_C_MC` or `right_hand_C_MC`
  with an identity transform. This preserves the vendor palm frame and makes
  the zero wrist pose use the same identity mount convention as XHand.
- Finger gains in `envs/hand_cfgs/sharpa.py` are the vendor's official MJCF
  position-actuator values (`wave_01/left_sharpa_wave.xml`): kp and joint-class
  grouping verbatim, force ranges from the vendor URDF effort limits, and kv
  realizing the vendor's `dampratio="0.9"` explicitly as
  `kv = 2*0.9*sqrt(kp*(armature + reflected link inertia))` per joint class.
  Wrist gains are the DexMachina floating-wrist convention shared by the
  shipped hands.
- Retargeting uses the neutral `scaling_factor: 1.0`; task-clip renders
  received visual alignment sign-off on 2026-07-31.

## SPIDER bundle

- Run `build_mjcf.py` with SPIDER's Python environment to regenerate
  `left.xml`, `right.xml`, and `bimanual.xml` from the bundled URDFs.
- The URDF wrist helper links carry the same small inertials used by SPIDER's
  XHand source URDFs so MuJoCo can compile the six moving wrist bodies.
- Finger position actuators inherit their exact URDF joint ranges and use the
  XHand MJCF defaults (`kp=300`, `dampratio=1`, `armature=1`). The six wrist
  position actuators per side use `kp=1000`.
- `left_palm` and `right_palm` use the vendor palm frame directly. The five
  fingertip sites reproduce the fixed `*_fingertip` link origins from the
  URDF after MuJoCo fuses those fixed links into the distal bodies.
